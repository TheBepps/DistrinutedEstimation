function ob_temp = obstBuild3d(map,num,detect_R)
    ob_temp=zeros(num,3);
    for i=1:num     %for each obstacle create a random (x,y) position
        flag=true;
        while flag  %check anchor-obstacle overlapping
            flag=false;
            ob_temp(i,1)=randi([1,map.dim]); 
            ob_temp(i,2)=randi([1,map.dim]);
            for k=1:(size(map.anchors_x,2))
                if norm(ob_temp(i,1:2)-[map.anchors_x(k), map.anchors_y(k)])<detect_R  %inconsistent ancor and avoidance point
                    flag=true;
                    break;
                end
            end
        end
        % after choosing X valid position
        ob_temp(i,3)=min(map.profile(ob_temp(i,2)*2, ob_temp(i,1)*2) + randi([3,30]), 0);  % obstacle Y position (must be under the zero level "water")
    end
end